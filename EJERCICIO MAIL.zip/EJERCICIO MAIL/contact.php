<?php
// the message
$msg = "FUNCIOOOONA SORRY PER OMPLIRTO TOT";

// use wordwrap() if lines are longer than 70 characters
$msg = wordwrap($msg,70);

// send email
mail("rocferrer77@gmail.com","DIOOOOS",$msg);
?>